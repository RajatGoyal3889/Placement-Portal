<?php

$dbcon=mysqli_connect("164.132.190.162","placeme1_new","qwerty");

mysqli_select_db($dbcon,"placeme1_users");

?>